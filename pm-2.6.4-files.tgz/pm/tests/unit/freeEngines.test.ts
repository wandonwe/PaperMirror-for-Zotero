import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
	calcGoogleTk,
	cleanGoogleAnnotatedText,
	escapeHTML,
	unescapeHTML,
	mapBingLang,
	mapGoogleLang,
	parseBingTranslatorPage,
	resolveBingApiBase,
	runPool,
	splitLongText
} from '../../src/translation/providers/freeEngineUtils';
import { parseGoogleEntries } from '../../src/translation/providers/googleFree';
import { PaperMirrorError } from '../../src/types/models';

test('calcGoogleTk is deterministic and shaped like tk', () => {
	const a = calcGoogleTk('Hello world');
	const b = calcGoogleTk('Hello world');
	const c = calcGoogleTk('Hello world!');
	assert.equal(a, b);
	assert.notEqual(a, c);
	assert.match(a, /^\d+\.\d+$/);
});

test('calcGoogleTk handles CJK and surrogate pairs', () => {
	assert.match(calcGoogleTk('影像组学与总生存期𝒳'), /^\d+\.\d+$/);
});

test('escape/unescape round-trip', () => {
	const s = `a < b & "c" > 'd'`;
	assert.equal(unescapeHTML(escapeHTML(s)), s);
});

test('cleanGoogleAnnotatedText strips pre/b/i annotations and unescapes', () => {
	const raw = '<pre><b>这是译文一。</b><i>This is source one.</i><b>这是译文二 &amp; 更多。</b><i>Second.</i></pre>';
	const cleaned = cleanGoogleAnnotatedText(raw);
	assert.equal(cleaned, '这是译文一。 这是译文二 & 更多。');
});

test('cleanGoogleAnnotatedText passes through unannotated text', () => {
	assert.equal(cleanGoogleAnnotatedText('简单译文'), '简单译文');
	assert.equal(cleanGoogleAnnotatedText('<pre>简单译文</pre>'), '简单译文');
});

test('parseGoogleEntries aligns strings and [text,lang] pairs', () => {
	assert.deepEqual(parseGoogleEntries(['一', '二'], 2), ['一', '二']);
	assert.deepEqual(parseGoogleEntries([['一', 'en'], ['二', 'en']], 2), ['一', '二']);
	assert.deepEqual(parseGoogleEntries('单条', 1), ['单条']);
});

test('parseGoogleEntries rejects count mismatches', () => {
	assert.throws(() => parseGoogleEntries(['只有一条'], 2), PaperMirrorError);
});

test('splitLongText respects limit and prefers sentence boundaries', () => {
	const text = 'First sentence. Second sentence is a bit longer! Third one? 第四句。';
	const parts = splitLongText(text, 30);
	assert.ok(parts.length >= 2);
	for (const part of parts) {
		assert.ok(part.length <= 30);
	}
	assert.equal(parts.join('').replace(/\s+/g, ' ').trim(), text.replace(/\s+/g, ' ').trim());
});

test('splitLongText hard-cuts a single huge sentence', () => {
	const parts = splitLongText('x'.repeat(2500), 900);
	assert.equal(parts.length, 3);
});

test('parseBingTranslatorPage extracts IG/IID/key/token', () => {
	const html = `
		<html><head><script>var x=1; IG:"ABCDEF1234567890"; </script></head>
		<body><div id="tta" data-iid="translator.5024.1"></div>
		<script>var params_RichTranslateHelper = [1721400000000,"qWeRtY123_-tokenvalue",3600000,true];</script>
		</body></html>`;
	const session = parseBingTranslatorPage(html);
	assert.ok(session);
	assert.equal(session!.ig, 'ABCDEF1234567890');
	assert.equal(session!.iid, 'translator.5024.1');
	assert.equal(session!.key, '1721400000000');
	assert.equal(session!.token, 'qWeRtY123_-tokenvalue');
});

test('parseBingTranslatorPage returns null on layout change', () => {
	assert.equal(parseBingTranslatorPage('<html>nothing here</html>'), null);
});

test('bing/google language mapping', () => {
	assert.equal(mapBingLang('auto'), 'auto-detect');
	assert.equal(mapBingLang('zh-CN'), 'zh-Hans');
	assert.equal(mapBingLang('zh-TW'), 'zh-Hant');
	assert.equal(mapBingLang('en'), 'en');
	assert.equal(mapGoogleLang('zh'), 'zh-CN');
	assert.equal(mapGoogleLang('auto'), 'auto');
});

test('parses the CURRENT bing page variable (params_AbusePreventionHelper)', () => {
	const html = `<html><div id="tta_input" data-iid="translator.5028"></div>
	<script>var params_AbusePreventionHelper = [1700000000000,"HgQ2rT9-tokenvalue_",3600000];</script>
	<script>_G={IG:"ABCDEF0123456789"};</script></html>`;
	const session = parseBingTranslatorPage(html);
	assert.ok(session, 'new variable name must parse');
	assert.equal(session!.key, '1700000000000');
	assert.equal(session!.token, 'HgQ2rT9-tokenvalue_');
	assert.equal(session!.ig, 'ABCDEF0123456789');
	assert.equal(session!.iid, 'translator.5028');
});

// ---- Bing API host selection (the www/cn token-mismatch regression) ---------

test('the API call follows the session-issuing host', () => {
	// Mainland: page 302s to cn.bing.com; the token is only valid THERE.
	assert.equal(resolveBingApiBase('', 'https://cn.bing.com'), 'https://cn.bing.com');
	assert.equal(resolveBingApiBase(undefined, 'https://www.bing.com'), 'https://www.bing.com');
});

test('the auto-filled default Base URL is not a real override', () => {
	// The settings pane writes the provider default (www.bing.com) into the
	// preference on its own; treating that as an override posted cn-issued
	// tokens to www — the exact bug that kept the engine dead.
	assert.equal(resolveBingApiBase('https://www.bing.com', 'https://cn.bing.com'), 'https://cn.bing.com');
	assert.equal(resolveBingApiBase('https://cn.bing.com/', 'https://www.bing.com'), 'https://www.bing.com');
	assert.equal(resolveBingApiBase('https://www.bing.com/', 'https://cn.bing.com'), 'https://cn.bing.com');
});

test('a genuine non-bing mirror IS an override', () => {
	assert.equal(
		resolveBingApiBase('https://bing-mirror.example.com', 'https://cn.bing.com'),
		'https://bing-mirror.example.com'
	);
	// Trailing slashes are normalised either way.
	assert.equal(
		resolveBingApiBase('https://bing-mirror.example.com/', 'https://cn.bing.com'),
		'https://bing-mirror.example.com'
	);
});

test('garbage in the Base URL fails CLOSED, not open (P3, 2.0.10)', () => {
	// 旧语义是回落 session origin(fail-open 静默出网)—— 现在保留原样,
	// 让 checkEndpointURL 报错给用户看。
	assert.equal(resolveBingApiBase('not a url', 'https://cn.bing.com'), 'not a url');
});

// ---- the request pool -------------------------------------------------------

test('runPool preserves order while running concurrently', async () => {
	const started: number[] = [];
	const results = await runPool([30, 10, 20], 3, async (delay, i) => {
		started.push(i);
		await new Promise(resolve => setTimeout(resolve, delay));
		return `r${i}`;
	});
	assert.deepEqual(results, ['r0', 'r1', 'r2'], 'results in input order regardless of finish order');
	assert.deepEqual(started.sort(), [0, 1, 2]);
});

test('runPool honours the concurrency cap', async () => {
	let inFlight = 0;
	let peak = 0;
	await runPool([1, 2, 3, 4, 5, 6], 2, async () => {
		inFlight++;
		peak = Math.max(peak, inFlight);
		await new Promise(resolve => setTimeout(resolve, 10));
		inFlight--;
	});
	assert.equal(peak, 2, 'never more than the cap in flight');
});

test('runPool propagates the first failure', async () => {
	await assert.rejects(
		runPool([1, 2, 3], 2, async (n) => {
			if (n === 2) {
				throw new Error('boom');
			}
			return n;
		}),
		/boom/
	);
});

// ---- P3 (2.0.6): 共享 in-flight promise 与调用方信号解耦 --------------------

test('raceSignal: 一个调用者取消只影响自己,共享结果继续供别人使用', async () => {
	const { raceSignal } = await import('../../src/translation/providers/bingFree');
	let resolveShared!: (v: string) => void;
	const shared = new Promise<string>(r => { resolveShared = r; });
	const ctrlA = new AbortController();
	const waiterA = raceSignal(shared, ctrlA.signal);
	const waiterB = raceSignal(shared, new AbortController().signal);
	ctrlA.abort(); // 标签页 A 取消(关页/翻页)
	await assert.rejects(waiterA, (e: unknown) =>
		e instanceof PaperMirrorError && e.code === 'CANCELLED');
	resolveShared('session-token'); // 共享请求没有被 A 的取消打断
	assert.equal(await waiterB, 'session-token', 'B 必须照常拿到共享结果');
});

test('raceSignal: 预先已取消 → 立即 CANCELLED;无 signal → 原样透传', async () => {
	const { raceSignal } = await import('../../src/translation/providers/bingFree');
	const aborted = new AbortController();
	aborted.abort();
	await assert.rejects(raceSignal(Promise.resolve('x'), aborted.signal), (e: unknown) =>
		e instanceof PaperMirrorError && e.code === 'CANCELLED');
	assert.equal(await raceSignal(Promise.resolve('y'), undefined), 'y');
});

// ---- P2-12 (2.0.8): 双通道组合错误继承主通道分类 ----------------------------

test('combineChannelError: 429 的 RATE_LIMITED + retryAfterMs 必须存活到组合错误', async () => {
	const { combineChannelError } = await import('../../src/translation/providers/bingFree');
	const scrape = new PaperMirrorError('RATE_LIMITED', 'too many requests', { httpStatus: 429, retryable: true });
	(scrape as PaperMirrorError & { retryAfterMs?: number }).retryAfterMs = 7000;
	const combined = combineChannelError(scrape, 'Bing通道: 429 ｜ Edge通道: 熔断中');
	assert.equal(combined.code, 'RATE_LIMITED', '洗成 BAD_RESPONSE 会让 lane 自适应限流失明');
	assert.equal(combined.httpStatus, 429);
	assert.equal(combined.retryable, true);
	assert.equal((combined as PaperMirrorError & { retryAfterMs?: number }).retryAfterMs, 7000,
		'Retry-After 丢失会退回 400ms 盲重试,真实限流下继续锤打');
	assert.match(combined.message, /Bing通道/);
});

test('combineChannelError: TIMEOUT 保留 (「只试一次」止损才生效);不可重试属性不被洗掉', async () => {
	const { combineChannelError } = await import('../../src/translation/providers/bingFree');
	const timeout = combineChannelError(new PaperMirrorError('TIMEOUT', 't', { retryable: true }), 'msg');
	assert.equal(timeout.code, 'TIMEOUT');
	const invalid = combineChannelError(new PaperMirrorError('INVALID_API_KEY', 'k', { retryable: false }), 'msg');
	assert.equal(invalid.retryable, false, '不可重试错误被洗成可重试会白烧请求');
});

test('combineChannelError: 非 PaperMirrorError 主通道错误退回 BAD_RESPONSE 可重试', async () => {
	const { combineChannelError } = await import('../../src/translation/providers/bingFree');
	const fallback = combineChannelError(null, 'Bing通道: weird ｜ Edge通道: down');
	assert.equal(fallback.code, 'BAD_RESPONSE');
	assert.equal(fallback.retryable, true);
});

// ---- P2-14 (2.0.9): 硬切不劈代理对 ------------------------------------------

test('splitLongText: 星面数学字符不被劈成孤立代理 (encodeURIComponent 不再抛)', () => {
	// 无句读的长串,充满占两个 UTF-16 单元的数学字母 —— 旧实现按固定步长
	// 硬切,奇数位切点必然落在代理对中间。
	const math = '𝑥𝛽𝛾𝛿𝜀'.repeat(40); // length = 400 (200 个星面字符)
	for (const maxLen of [7, 30, 33, 101]) {
		const parts = splitLongText(math, maxLen);
		assert.equal(parts.join(''), math, `maxLen=${maxLen}: 内容无损`);
		for (const p of parts) {
			assert.doesNotThrow(() => encodeURIComponent(p),
				`maxLen=${maxLen}: 任何分片都不得含孤立代理 (URIError → 整页不可重试地失败)`);
		}
	}
	// 纯 ASCII 行为不变。
	const ascii = 'x'.repeat(50);
	assert.deepEqual(splitLongText(ascii, 20).map(p => p.length), [20, 20, 10]);
});

// ---- P3 (2.0.10): fail-closed 与 CJK 拼接 -----------------------------------

test('无 scheme 的自定义 Bing base fail-closed: 算覆盖、不静默出网', async () => {
	const { hasCustomBingBase } = await import('../../src/translation/providers/bingFree');
	// 用户想收进内网代理但漏写 scheme —— 旧行为当「未覆盖」照旧出网微软。
	assert.equal(hasCustomBingBase('myproxy.internal/bing'), true, '解析失败的非空 base 必须算自定义覆盖');
	assert.equal(resolveBingApiBase('myproxy.internal/bing', 'https://www.bing.com'), 'myproxy.internal/bing',
		'保留原样让 checkEndpointURL 报错给用户看,而不是回落官方源');
	// 既有语义不变: 空串与 bing.com 都不算覆盖。
	assert.equal(hasCustomBingBase(''), false);
	assert.equal(hasCustomBingBase('https://www.bing.com'), false);
	assert.equal(resolveBingApiBase('', 'https://cn.bing.com'), 'https://cn.bing.com');
});

test('joinTranslatedParts: CJK 目标语言空串拼接,其余保留空格', async () => {
	const { joinTranslatedParts } = await import('../../src/translation/providers/freeEngineUtils');
	assert.equal(joinTranslatedParts(['影像组学', '与总生存期'], 'zh-Hans'), '影像组学与总生存期', '切点不得留句中空格');
	assert.equal(joinTranslatedParts(['翻訳', 'テスト'], 'ja'), '翻訳テスト');
	assert.equal(joinTranslatedParts(['first part', 'second part'], 'en'), 'first part second part');
	assert.equal(joinTranslatedParts(['erste', 'zweite'], 'de'), 'erste zweite');
});
