import { test } from 'node:test';
import assert from 'node:assert/strict';

/** 单调递增的假 mtime —— 跨用例不复用，避免陈旧指纹意外命中。 */
let mtimeClock = 1_000;

/**
 * 段落缓存写入串行化 (1.3.0, 审核 P1): 并发 writeSegments 曾是
 * 读旧文件 → 合并 → 原子覆盖 —— 两个页面同时读到 {x},后写者覆盖先写者的
 * 合并结果。现在同一路径的写排队执行,两次并发写的条目必须全部存活。
 * 用带人为延迟的假 IOUtils 重现旧竞态窗口。
 */

function installIO(): { files: Map<string, unknown>; teardown: () => void; readDelayMs: number } {
	const files = new Map<string, unknown>();
	// 文件元数据: 2.5.3 的解析缓存用 (size, lastModified) 作指纹，假 IOUtils
	// 必须真的模拟 stat，否则这些用例走的是「指纹拿不到 → 每次重读」的退化
	// 路径，等于没测到缓存。mtime 全局单调递增，跨用例绝不重复。
	const meta = new Map<string, { size: number; lastModified: number }>();
	const state = { readDelayMs: 0 };
	const stampFile = (p: string, data: unknown): void => {
		meta.set(p, { size: JSON.stringify(data).length, lastModified: ++mtimeClock });
	};
	const delay = (ms: number): Promise<void> => new Promise(r => setTimeout(r, ms));
	(globalThis as Record<string, any>).IOUtils = {
		exists: async (p: string) => files.has(p),
		readJSON: async (p: string) => {
			await delay(state.readDelayMs); // 竞态窗口: 读到旧内容后让出事件循环
			if (!files.has(p)) {
				throw new Error('ENOENT');
			}
			return JSON.parse(JSON.stringify(files.get(p)));
		},
		writeJSON: async (p: string, data: unknown) => {
			await delay(1);
			files.set(p, JSON.parse(JSON.stringify(data)));
			stampFile(p, data);
		},
		makeDirectory: async () => {},
		remove: async (p: string) => { files.delete(p); meta.delete(p); },
		getChildren: async () => [],
		stat: async (p: string) => {
			const m = meta.get(p);
			if (!m) {
				throw new Error('ENOENT');
			}
			return { type: 'regular', size: m.size, lastModified: m.lastModified };
		}
	};
	(globalThis as Record<string, any>).PathUtils = {
		join: (...parts: string[]) => parts.join('/'),
		parent: (p: string) => p.split('/').slice(0, -1).join('/'),
		filename: (p: string) => p.split('/').pop() ?? p
	};
	(globalThis as Record<string, any>).Zotero = { DataDirectory: { dir: '/data' } };
	return {
		files,
		/**
		 * 模拟「别的进程动过这个文件」: 把所有文件的 mtime 往前推。2.5.3 的
		 * 解析缓存以 (size, lastModified) 为指纹，这一下就让它整体失效，回到
		 * 必须真读磁盘的路径 —— 下面几条基底读失败的用例正需要那条路径。
		 */
		bumpMtime: () => {
			for (const [p, m] of meta) {
				meta.set(p, { size: m.size, lastModified: (mtimeClock += 100) });
			}
		},
		get readDelayMs() { return state.readDelayMs; },
		set readDelayMs(v: number) { state.readDelayMs = v; },
		teardown: () => {
			delete (globalThis as Record<string, any>).IOUtils;
			delete (globalThis as Record<string, any>).PathUtils;
			delete (globalThis as Record<string, any>).Zotero;
		}
	} as any;
}

test('并发 writeSegments 不再互相覆盖: 两个页面的段落全部存活', async () => {
	const io = installIO();
	io.readDelayMs = 10; // 制造旧竞态的交错窗口
	try {
		const { writeSegments, readSegments, setSegmentFlushDelayMs } = await import('../../src/cache/cacheManager');
		setSegmentFlushDelayMs(0); // 确定性即时落盘(不改语义,仅去掉节流窗口)
		const parts = {
			attachmentKey: 'K1', fileHash: 'H1', provider: 'openai', model: 'm',
			promptVersion: 2, customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		// 两个"页面"同时写入不同的段落 —— 旧实现里后写者会覆盖先写者
		await Promise.all([
			writeSegments(parts, [{ hash: 'seg-a', translatedText: '甲' }]),
			writeSegments(parts, [{ hash: 'seg-b', translatedText: '乙' }])
		]);
		const out = await readSegments(parts, ['seg-a', 'seg-b']);
		assert.equal(out.get('seg-a'), '甲', '先写者的段落必须存活');
		assert.equal(out.get('seg-b'), '乙', '后写者的段落必须存活');
	}
	finally { io.teardown(); }
});

test('高并发 8 路写全部存活', async () => {
	const io = installIO();
	io.readDelayMs = 3;
	try {
		const { writeSegments, readSegments, setSegmentFlushDelayMs } = await import('../../src/cache/cacheManager');
		setSegmentFlushDelayMs(0); // 确定性即时落盘(不改语义,仅去掉节流窗口)
		const parts = {
			attachmentKey: 'K2', fileHash: 'H2', provider: 'openai', model: 'm',
			promptVersion: 2, customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		await Promise.all(Array.from({ length: 8 }, (_, i) =>
			writeSegments(parts, [{ hash: `s${i}`, translatedText: `译${i}` }])));
		const out = await readSegments(parts, Array.from({ length: 8 }, (_, i) => `s${i}`));
		assert.equal(out.size, 8, '8 路并发写一个不丢');
	}
	finally { io.teardown(); }
});

// ---- 2.2.4 (item5): 内存合并 + 节流落盘 —— 去掉整篇 O(N²) 全量重写 -----------

test('节流窗口内多次 writeSegments 坍缩为一次落盘, 条目全存活', async () => {
	const io = installIO();
	try {
		const mod = await import('../../src/cache/cacheManager');
		mod.setSegmentFlushDelayMs(30); // 一个真实收集窗口
		let writes = 0;
		const realWrite = (globalThis as Record<string, any>).IOUtils.writeJSON;
		(globalThis as Record<string, any>).IOUtils.writeJSON = async (p: string, d: unknown) => { writes++; return realWrite(p, d); };
		const parts = {
			attachmentKey: 'KC', fileHash: 'HC', provider: 'openai', model: 'm',
			promptVersion: 2, customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		// 6 个"页面"各写一条,都落在同一个 30ms 收集窗口内 → 应只落盘一次(旧实现是 6 次全库重写)。
		const proms = Array.from({ length: 6 }, (_, i) =>
			mod.writeSegments(parts, [{ hash: `c${i}`, translatedText: `译${i}` }]));
		await Promise.all(proms);
		assert.equal(writes, 1, `窗口内 6 次写应坍缩为 1 次落盘, 实际 ${writes}`);
		const out = await mod.readSegments(parts, Array.from({ length: 6 }, (_, i) => `c${i}`));
		assert.equal(out.size, 6, '坍缩后 6 条段落一个不少');
	}
	finally { io.teardown(); }
});

test('落盘前 pending 对 readSegments 可见 (跨页去重不因节流丢失)', async () => {
	const io = installIO();
	try {
		const mod = await import('../../src/cache/cacheManager');
		mod.setSegmentFlushDelayMs(50);
		const parts = {
			attachmentKey: 'KP', fileHash: 'HP', provider: 'openai', model: 'm',
			promptVersion: 2, customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		const wp = mod.writeSegments(parts, [{ hash: 'pz', translatedText: '预览' }]); // 不 await
		const before = await mod.readSegments(parts, ['pz']); // 文件尚未落盘 → 应从 pending 命中
		assert.equal(before.get('pz'), '预览', '尚未落盘也应从内存 pending 命中');
		await wp; // 窗口到点,落盘完成
		const after = await mod.readSegments(parts, ['pz']);
		assert.equal(after.get('pz'), '预览', '落盘后从磁盘命中');
	}
	finally { io.teardown(); }
});

// ---- P2-1 (2.0.7): 合并基底读失败不得以空库覆盖 -----------------------------

test('合并基底瞬时读失败 → 放弃本次写,已有段落库不被截断', async () => {
	const io = installIO();
	try {
		const { writeSegments, readSegments, setSegmentFlushDelayMs } = await import('../../src/cache/cacheManager');
		setSegmentFlushDelayMs(0); // 确定性即时落盘(不改语义,仅去掉节流窗口)
		const parts = {
			attachmentKey: 'K9', fileHash: 'H9', provider: 'openai', model: 'm',
			promptVersion: 2, customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		// 建立既有库: 两条段落。
		await writeSegments(parts, [
			{ hash: 'old-1', translatedText: '既有译文一' },
			{ hash: 'old-2', translatedText: '既有译文二' }
		]);
		// 先让解析缓存失效 —— 缓存命中时根本不读盘，读失败这条路走不到 (2.5.3)。
		(io as any).bumpMtime();
		// 下一次合并写的基底读取瞬时失败 (文件被占用/网盘同步)。
		(globalThis as Record<string, any>).IOUtils.readJSON = async () => {
			throw new Error('NS_ERROR_FILE_IS_LOCKED');
		};
		await writeSegments(parts, [{ hash: 'new-3', translatedText: '新增译文三' }]);
		// 恢复读取,检查库内容。
		const files = io.files as Map<string, unknown>;
		(globalThis as Record<string, any>).IOUtils.readJSON = async (p: string) => {
			if (!files.has(p)) {
				throw new Error('ENOENT');
			}
			return JSON.parse(JSON.stringify(files.get(p)));
		};
		const out = await readSegments(parts, ['old-1', 'old-2', 'new-3']);
		assert.equal(out.get('old-1'), '既有译文一', '既有段落必须存活 —— 旧实现在这里被截断清空');
		assert.equal(out.get('old-2'), '既有译文二');
		assert.equal(out.has('new-3'), false, '本次合并被放弃 (少写几条好过丢整库)');
	}
	finally { io.teardown(); }
});

test('合并基底 JSON 确认损坏 (SyntaxError) → 允许以空库重建', async () => {
	const io = installIO();
	try {
		const { writeSegments, readSegments, setSegmentFlushDelayMs } = await import('../../src/cache/cacheManager');
		setSegmentFlushDelayMs(0); // 确定性即时落盘(不改语义,仅去掉节流窗口)
		const parts = {
			attachmentKey: 'K10', fileHash: 'H10', provider: 'openai', model: 'm',
			promptVersion: 2, customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		await writeSegments(parts, [{ hash: 'a', translatedText: '旧' }]);
		const files = io.files as Map<string, unknown>;
		// 文件被外部写坏 = mtime 变了，解析缓存随之失效 (2.5.3)。
		(io as any).bumpMtime();
		const restore = (globalThis as Record<string, any>).IOUtils.readJSON;
		(globalThis as Record<string, any>).IOUtils.readJSON = async () => {
			throw new SyntaxError('Unexpected end of JSON input');
		};
		await writeSegments(parts, [{ hash: 'b', translatedText: '重建' }]);
		(globalThis as Record<string, any>).IOUtils.readJSON = restore;
		void files;
		const out = await readSegments(parts, ['a', 'b']);
		assert.equal(out.has('a'), false, '损坏库被重建,旧条目不复存在');
		assert.equal(out.get('b'), '重建', '重建后的写入生效');
	}
	finally { io.teardown(); }
});

// ---- 2.3.5 (第四批 item7 · API-3): 跨文档共享段落库 -------------------------

test('段落库跨文档共享: A 文档写入的段落, B 文档同 context 直接命中', async () => {
	const io = installIO();
	try {
		const mod = await import('../../src/cache/cacheManager');
		mod.setSegmentFlushDelayMs(0);
		const ctx = {
			provider: 'openai', model: 'm', promptVersion: 2,
			customPromptHash: 'cp', glossaryHash: 'g', noTranslateHash: 'n', settingsHash: 's'
		};
		const docA = { attachmentKey: 'DOC-A', fileHash: 'HA', ...ctx };
		const docB = { attachmentKey: 'DOC-B', fileHash: 'HB', ...ctx };
		await mod.writeSegments(docA, [{ hash: 'boilerplate-1', translatedText: '样板句译文' }]);
		const hit = await mod.readSegments(docB, ['boilerplate-1']);
		assert.equal(hit.get('boilerplate-1'), '样板句译文', '跨文档同 context 命中,0 请求');
		// context 不同(换模型)则隔离不串。
		const docC = { attachmentKey: 'DOC-B', fileHash: 'HB', ...ctx, model: 'other-model' };
		const miss = await mod.readSegments(docC, ['boilerplate-1']);
		assert.equal(miss.has('boilerplate-1'), false, '不同 context 不得串库');
	}
	finally { io.teardown(); }
});
