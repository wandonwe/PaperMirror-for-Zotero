# 性能基线报告(真实世界)

基于 1 篇文档的诊断 JSON 汇总。指标口径见 docs/reviews/性能基线-操作指南.md。

| doc | pages | requests | reqPerPage | salvage | rate429 | timeouts | segHits | avgPageMs | translated | preserved | keptOriginal | placed | keptPlace | placeRate | geoViolations | annexed | inkBlocked | pageHitRate | segHitRate | prefetchWaste | unplaced | inTokens | outTokens | cachedPct | tokPerPage | layoutMs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| diag2-d22 | 14 | 32 | 2.29 | 0 | 0 | 0 | 5 | 5936 | 236 | 62 | 0 | 194 | 15 | 92.8% | 0 | 1 | 64 | 0% | 2% | 1/13 | 0 | 0 | 0 | n/a | 0 | 0 |
| 合计 (1 篇) | 14 | 32 | 2.29 | 0 | 0 | 0 | 5 | 5936 | 236 | 62 | 0 | 194 | 15 | 92.8% | 0 | 1 | 64 | — | — | — | 0 | 0 | 0 | — | 0 | 0 |
